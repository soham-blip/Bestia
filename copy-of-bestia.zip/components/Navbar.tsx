
import React, { useState, useEffect } from 'react';
import { NAV_ITEMS, RESTAURANT_INFO } from '../constants';

interface NavbarProps {
  onNavigate: (view: 'home' | 'menu' | 'events') => void;
}

const Navbar: React.FC<NavbarProps> = ({ onNavigate }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleLinkClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    // ALWAYS prevent default to stop the browser from trying to navigate/reload
    e.preventDefault();
    
    // Determine if we're navigating to a main view or a section
    const isMenu = href === '#/menu';
    const isEvents = href === '#/events';
    const isHome = href === '#/' || href === '#';
    const isSection = href.startsWith('#') && !isMenu && !isEvents && !isHome;

    if (isMenu) {
      onNavigate('menu');
    } else if (isEvents) {
      onNavigate('events');
    } else if (isHome) {
      onNavigate('home');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else if (isSection) {
      const sectionId = href.substring(1);
      
      // Check if we are currently on home by looking at the view state logic via App.tsx
      // Since Navbar is a child, we trust onNavigate to handle the state.
      // We'll call onNavigate('home') just to be sure we are on the right view.
      onNavigate('home');
      
      // We use a small timeout to allow the 'home' view to mount if we were on another page
      setTimeout(() => {
        const element = document.getElementById(sectionId);
        if (element) {
          const offset = 80; // Account for fixed navbar height
          const bodyRect = document.body.getBoundingClientRect().top;
          const elementRect = element.getBoundingClientRect().top;
          const elementPosition = elementRect - bodyRect;
          const offsetPosition = elementPosition - offset;

          window.scrollTo({
            top: offsetPosition,
            behavior: 'smooth'
          });
        }
      }, 100);
    }
    
    setIsMobileMenuOpen(false);
  };

  return (
    <nav className={`fixed w-full z-50 transition-all duration-300 ${isScrolled ? 'bg-black/95 py-3 border-b border-white/10' : 'bg-transparent py-6'}`}>
      <div className="max-w-7xl mx-auto px-6 flex justify-between items-center">
        <a 
          href="#/" 
          onClick={(e) => handleLinkClick(e, '#/')}
          className="text-3xl font-serif tracking-widest font-bold"
        >
          BESTIA
        </a>
        
        {/* Desktop Menu */}
        <div className="hidden md:flex space-x-8 items-center">
          {NAV_ITEMS.map((item) => (
            <a 
              key={item.label} 
              href={item.href} 
              onClick={(e) => handleLinkClick(e, item.href)}
              className="text-xs uppercase tracking-widest hover:text-red-500 transition-colors"
            >
              {item.label}
            </a>
          ))}
        </div>

        {/* Mobile Toggle */}
        <button 
          className="md:hidden text-white"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        >
          {isMobileMenuOpen ? (
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
          ) : (
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16m-7 6h7" /></svg>
          )}
        </button>
      </div>

      {/* Mobile Menu Overlay */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-black fixed inset-0 z-[100] flex flex-col items-center justify-center space-y-8">
          {NAV_ITEMS.map((item) => (
            <a 
              key={item.label} 
              href={item.href} 
              className="text-2xl font-serif tracking-widest"
              onClick={(e) => handleLinkClick(e, item.href)}
            >
              {item.label}
            </a>
          ))}
          <button 
            onClick={() => setIsMobileMenuOpen(false)}
            className="absolute top-6 right-6 text-white"
          >
            <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
          </button>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
