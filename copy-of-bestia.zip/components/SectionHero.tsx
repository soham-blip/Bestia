
import React from 'react';
import { RESTAURANT_INFO } from '../constants';

interface HeroProps {
  onMenuClick?: () => void;
}

const SectionHero: React.FC<HeroProps> = ({ onMenuClick }) => {
  return (
    <section id="hero" className="relative h-screen w-full overflow-hidden flex items-center justify-center">
      {/* Background Image with Overlay */}
      <div 
        className="absolute inset-0 z-0 scale-105 animate-slow-zoom"
        style={{
          backgroundImage: `linear-gradient(rgba(0,0,0,0.6), rgba(0,0,0,0.6)), url('https://picsum.photos/id/42/1920/1080')`,
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}
      />
      
      <div className="relative z-10 text-center px-6 max-w-4xl">
        <h1 className="text-6xl md:text-9xl font-serif mb-6 tracking-tight">Bestia</h1>
        <p className="text-sm md:text-lg uppercase tracking-[0.3em] font-light mb-10 text-gray-300">
          Industrial. Rustic. Italian. Los Angeles.
        </p>
        <div className="flex flex-col md:flex-row gap-4 justify-center items-center">
          <button 
            onClick={onMenuClick}
            className="w-48 py-4 border border-white/30 hover:bg-white hover:text-black transition-all text-xs uppercase tracking-widest"
          >
            Explore Menu
          </button>
          <a 
            href={RESTAURANT_INFO.links.reservations}
            target="_blank"
            rel="noopener noreferrer"
            className="w-48 py-4 bg-red-700 hover:bg-red-800 text-white transition-all text-xs uppercase tracking-widest"
          >
            Book a Table
          </a>
        </div>
      </div>

      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 animate-bounce opacity-50">
        <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
        </svg>
      </div>

      <style>{`
        @keyframes slow-zoom {
          0% { transform: scale(1); }
          100% { transform: scale(1.1); }
        }
        .animate-slow-zoom {
          animation: slow-zoom 20s infinite alternate ease-in-out;
        }
      `}</style>
    </section>
  );
};

export default SectionHero;
