
import React from 'react';
import { RESTAURANT_INFO } from '../constants';

interface SectionReservationsProps {
  onEventsClick?: () => void;
}

const SectionReservations: React.FC<SectionReservationsProps> = ({ onEventsClick }) => {
  return (
    <section id="reservations" className="py-24 bg-[#111]">
      <div className="max-w-5xl mx-auto px-6 text-center">
        <h2 className="text-4xl md:text-6xl font-serif mb-12 italic">Experience Bestia</h2>
        
        <div className="grid md:grid-cols-3 gap-12 mb-16">
          <div className="p-10 border border-white/10 hover:border-red-700/50 transition-all bg-black/30">
            <h3 className="text-xs uppercase tracking-[0.3em] text-gray-400 mb-6">Reservations</h3>
            <p className="text-sm font-light mb-8">Book your table through OpenTable for parties up to 6.</p>
            <a 
              href={RESTAURANT_INFO.links.reservations}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block px-8 py-3 bg-red-700 text-white text-xs uppercase tracking-widest hover:bg-red-800 transition-all"
            >
              Book Now
            </a>
          </div>

          <div className="p-10 border border-white/10 hover:border-red-700/50 transition-all bg-black/30">
            <h3 className="text-xs uppercase tracking-[0.3em] text-gray-400 mb-6">Events</h3>
            <p className="text-sm font-light mb-8">Host your private events and large group dinners with us.</p>
            <button 
              onClick={onEventsClick}
              className="inline-block px-8 py-3 border border-white text-white text-xs uppercase tracking-widest hover:bg-white hover:text-black transition-all"
            >
              Inquire
            </button>
          </div>

          <div className="p-10 border border-white/10 hover:border-red-700/50 transition-all bg-black/30">
            <h3 className="text-xs uppercase tracking-[0.3em] text-gray-400 mb-6">Gift Cards</h3>
            <p className="text-sm font-light mb-8">Share the Bestia experience with a digital gift card.</p>
            <a 
              href={RESTAURANT_INFO.links.giftCards}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block px-8 py-3 border border-white text-white text-xs uppercase tracking-widest hover:bg-white hover:text-black transition-all"
            >
              Purchase
            </a>
          </div>
        </div>

        <div id="contact" className="mt-24 pt-16 border-t border-white/5 grid md:grid-cols-2 gap-16 text-left">
          <div>
            <h4 className="text-2xl font-serif mb-6">Location & Contact</h4>
            <div className="space-y-4 text-gray-400 text-sm font-light">
              <p>{RESTAURANT_INFO.address}</p>
              <p>{RESTAURANT_INFO.phone}</p>
              <p>General Inquiries: info@bestiala.com</p>
            </div>
          </div>
          <div>
            <h4 className="text-2xl font-serif mb-6">Hours of Service</h4>
            <div className="space-y-4 text-gray-400 text-sm font-light">
              <p>Open Daily</p>
              <p>{RESTAURANT_INFO.hours}</p>
              <p className="text-xs italic text-red-500">* Closed for major holidays</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default SectionReservations;
