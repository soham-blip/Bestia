
import React from 'react';

const SectionAbout: React.FC = () => {
  return (
    <section id="about" className="py-24 bg-white text-black">
      <div className="max-w-7xl mx-auto px-6 grid md:grid-cols-2 gap-16 items-center">
        <div className="relative">
          <img 
            src="https://picsum.photos/id/491/800/1000" 
            alt="Interior of Bestia" 
            className="w-full h-auto grayscale hover:grayscale-0 transition-all duration-700 shadow-2xl"
          />
          <div className="absolute -bottom-8 -right-8 w-64 h-64 bg-black/5 -z-10"></div>
        </div>
        
        <div className="space-y-8">
          <span className="text-xs uppercase tracking-[0.4em] text-red-700 font-semibold italic">Our Story</span>
          <h2 className="text-4xl md:text-6xl font-serif leading-tight">In 2012, Chef Ori Menashe and Genevieve Gergis found themselves in a vacant warehouse, down a dimly lit alleyway...</h2>
          <div className="space-y-6 text-gray-700 leading-relaxed font-light">
            <p>
              In 2012, Chef Ori Menashe and Genevieve Gergis found themselves in a vacant warehouse, down a dimly lit alleyway in the Arts District. It was here that they would open Bestia, a multi-regional Italian restaurant.
            </p>
            <p>
              Bestia is the product of Ori and Genevieve’s hard work and passion. They both grew up in Los Angeles and are proud to be part of the city’s culinary community. The name "Bestia" (Italian for "Beast") echoed the beastly challenge of opening a restaurant in a then-developing neighborhood.
            </p>
            <p>
              The menu features multi-regional Italian dishes, with a focus on house-made charcuterie, handmade pastas, and pizza from a wood-burning oven. The space, designed by Studio Unltd, features industrial elements—raw surfaces and metal fixtures—tempered by warm woods and the glow of the open kitchen.
            </p>
            <p>
              Bestia continues to be a cornerstone of the Los Angeles dining scene, representing the intersection of industrial energy and timeless Italian tradition, where every detail from the handmade pasta to the artisanal cocktails reflects the founders' commitment to quality and community.
            </p>
          </div>
          <div className="pt-6">
            <div className="h-px w-24 bg-red-700 mb-6"></div>
            <p className="text-xs uppercase tracking-widest font-bold text-black italic">
              - Ori Menashe & Genevieve Gergis
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default SectionAbout;
