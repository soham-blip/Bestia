
import React, { useState } from 'react';
import { MENU_DATA } from '../constants';

interface SectionMenuProps {
  onExpand?: () => void;
}

const SectionMenu: React.FC<SectionMenuProps> = ({ onExpand }) => {
  const categories = ['ANTIPASTI', 'PIZZE', 'PASTE'];
  const [activeTab, setActiveTab] = useState(categories[0]);

  return (
    <section id="menu" className="py-24 bg-[#0a0a0a]">
      <div className="max-w-5xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-serif mb-4">Our Menu</h2>
          <div className="h-px w-24 bg-red-700 mx-auto"></div>
          <p className="mt-8 text-gray-400 max-w-2xl mx-auto text-sm leading-relaxed">
            A celebration of rustic Italian cooking, featuring artisanal pizzas, hand-made pastas, and wood-fired meats, 
            sourced from the finest local and imported ingredients.
          </p>
        </div>

        {/* Category Tabs */}
        <div className="flex flex-wrap justify-center gap-4 mb-16 border-b border-white/5 pb-4">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setActiveTab(cat)}
              className={`text-xs uppercase tracking-widest px-4 py-2 transition-all ${activeTab === cat ? 'text-red-500 border-b border-red-500' : 'text-gray-500 hover:text-white'}`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Menu Items Preview */}
        <div className="grid md:grid-cols-2 gap-x-16 gap-y-12 mb-16">
          {MENU_DATA.filter(item => item.category === activeTab).slice(0, 4).map(item => (
            <div key={item.id} className="group cursor-default">
              <div className="flex justify-between items-baseline mb-2 border-b border-dashed border-white/10 pb-1">
                <h3 className="text-xl font-serif tracking-wide group-hover:text-red-400 transition-colors">{item.name}</h3>
                <span className="text-sm font-light text-gray-400">${item.price}</span>
              </div>
              <p className="text-xs text-gray-500 italic font-light leading-relaxed uppercase tracking-tighter">{item.description}</p>
            </div>
          ))}
        </div>

        <div className="text-center">
          <button 
            onClick={onExpand}
            className="px-10 py-4 border border-white hover:bg-white hover:text-black transition-all text-xs uppercase tracking-[0.3em]"
          >
            View Full Menu
          </button>
        </div>

        <div className="mt-20 p-8 border border-white/5 bg-white/5 text-center">
          <p className="text-xs text-gray-500 uppercase tracking-widest leading-loose">
            * Menu items are subject to seasonal availability. <br />
            A 4% service charge is added to guest checks to support staff compensation and benefits.
          </p>
        </div>
      </div>
    </section>
  );
};

export default SectionMenu;
