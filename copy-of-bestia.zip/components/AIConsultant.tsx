
import React, { useState } from 'react';
import { GoogleGenAI } from '@google/genai';
import { MENU_DATA } from '../constants';

const AIConsultant: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [response, setResponse] = useState('');
  const [loading, setLoading] = useState(false);

  const handleAsk = async () => {
    if (!query) return;
    setLoading(true);
    setResponse('');
    
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });
      const menuContext = JSON.stringify(MENU_DATA);
      
      const res = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `You are Bestia's digital sommelier and host. 
          Given our current menu: ${menuContext}, answer this guest question: "${query}". 
          Be sophisticated, warm, and helpful. Recommend specific dishes.`,
        config: {
          systemInstruction: "You are the digital concierge for Bestia Restaurant. Keep answers concise and appetizing."
        }
      });

      setResponse(res.text || 'Apologies, I am unable to assist at this moment.');
    } catch (error) {
      setResponse("I'm sorry, I'm resting between services. Please try again later.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed bottom-6 right-6 z-[60]">
      {isOpen ? (
        <div className="bg-[#1a1a1a] border border-white/10 w-80 md:w-96 rounded-lg shadow-2xl overflow-hidden animate-fade-in-up">
          <div className="bg-red-700 p-4 flex justify-between items-center">
            <span className="text-xs uppercase tracking-widest font-bold">Bestia Concierge</span>
            <button onClick={() => setIsOpen(false)} className="text-white hover:text-black">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
            </button>
          </div>
          <div className="p-6">
            <p className="text-xs text-gray-400 mb-4">Ask me anything about our menu, wine pairings, or the Bestia experience.</p>
            <div className="mb-4">
              <textarea 
                className="w-full bg-black/50 border border-white/10 p-3 text-sm text-white focus:outline-none focus:border-red-700 h-24 resize-none"
                placeholder="What should I order if I love seafood?"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
              />
            </div>
            <button 
              onClick={handleAsk}
              disabled={loading}
              className="w-full bg-white text-black text-xs uppercase tracking-widest font-bold py-3 hover:bg-gray-200 transition-all disabled:opacity-50"
            >
              {loading ? 'Consulting Chef...' : 'Ask Concierge'}
            </button>
            {response && (
              <div className="mt-6 pt-6 border-t border-white/10 text-sm leading-relaxed text-gray-300 max-h-48 overflow-y-auto font-light">
                {response}
              </div>
            )}
          </div>
        </div>
      ) : (
        <button 
          onClick={() => setIsOpen(true)}
          className="bg-red-700 hover:bg-red-800 text-white p-4 rounded-full shadow-2xl transition-all transform hover:scale-110 flex items-center space-x-2"
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
          </svg>
          <span className="hidden md:inline text-xs uppercase tracking-widest font-bold">Ask Concierge</span>
        </button>
      )}
      <style>{`
        @keyframes fade-in-up {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .animate-fade-in-up {
          animation: fade-in-up 0.3s ease-out;
        }
      `}</style>
    </div>
  );
};

export default AIConsultant;
