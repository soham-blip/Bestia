
import React from 'react';

const EventsPage: React.FC = () => {
  return (
    <div className="bg-[#121212] min-h-screen pt-32 pb-24 px-6 animate-fade-in">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-20">
          <h1 className="text-6xl md:text-8xl font-serif mb-6 tracking-tight italic">Events</h1>
          <p className="text-xs uppercase tracking-[0.4em] text-gray-400">Private Dining & Buyouts</p>
        </div>

        <div className="space-y-16">
          <section className="border-b border-white/10 pb-16">
            <h2 className="text-3xl font-serif mb-8 text-red-700 tracking-wide">Large Group Events</h2>
            <div className="space-y-6 text-gray-300 leading-relaxed font-light text-lg">
              <p>
                Bestia offers a variety of options for large group dining and private events.
              </p>
              <p>
                Large groups can be accommodated on our beautiful Terrace or inside our Dining Room. Our terrace is a covered, outdoor space that can be used for semi-private events for up to 40 guests.
              </p>
              <p>
                For larger parties, we offer partial and full buyouts of the restaurant. We offer various formats for events, including partial and full buyouts.
              </p>
            </div>
          </section>

          <section className="border-b border-white/10 pb-16">
            <h2 className="text-3xl font-serif mb-8 text-red-700 tracking-wide">Special Occasions</h2>
            <div className="grid md:grid-cols-2 gap-10">
              <div className="space-y-4">
                <p className="text-gray-300 font-light leading-relaxed">
                  Whether you are planning a birthday, wedding, corporate event, business lunch, or special celebration, our events team will work with you to create a memorable experience.
                </p>
                <ul className="text-xs uppercase tracking-widest text-gray-500 space-y-2">
                  <li>• BIRTHDAYS</li>
                  <li>• CORPORATE EVENTS</li>
                  <li>• BUSINESS LUNCHES</li>
                  <li>• WEDDINGS</li>
                  <li>• HOLIDAY CELEBRATIONS</li>
                </ul>
              </div>
              <div className="bg-white/5 p-8 border border-white/10">
                <h3 className="text-xs uppercase tracking-[0.3em] text-gray-400 mb-6">Availability</h3>
                <p className="text-sm text-gray-400 font-light">
                  Event availability varies by season and day of the week. Please reach out to our team with your desired date and guest count for a personalized quote.
                </p>
              </div>
            </div>
          </section>

          <section className="text-center pt-8">
            <div className="inline-block border border-red-700 p-12 bg-red-700/5">
              <h2 className="text-2xl font-serif mb-6 tracking-widest">Inquire Now</h2>
              <p className="text-gray-300 mb-8 font-light italic text-xl">
                FOR INQUIRIES please contact our Events Director via email events@bestiala.com
              </p>
              <a 
                href="mailto:events@bestiala.com" 
                className="inline-block px-10 py-4 bg-red-700 text-white text-xs uppercase tracking-widest hover:bg-red-800 transition-all font-bold"
              >
                Send Email
              </a>
            </div>
          </section>
        </div>
      </div>
      <style>{`
        @keyframes fade-in {
          from { opacity: 0; transform: translateY(10px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .animate-fade-in {
          animation: fade-in 0.8s ease-out;
        }
      `}</style>
    </div>
  );
};

export default EventsPage;
