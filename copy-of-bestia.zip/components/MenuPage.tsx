
import React from 'react';
import { MENU_DATA, WINE_INFO, RESTAURANT_INFO } from '../constants';

const MenuPage: React.FC = () => {
  const categories = [
    'ANTIPASTI', 'PIZZE', 'PASTE', 'SECONDI', 'DOLCI', 'COCKTAILS', 'BEER & CIDER', 'NON-ALCOHOLIC'
  ];

  return (
    <div className="bg-[#121212] min-h-screen pt-32 pb-24 px-6 animate-fade-in">
      <div className="max-w-4xl mx-auto">
        {/* Menu Header */}
        <div className="text-center mb-24 border-b border-white/10 pb-16">
          <h1 className="text-6xl md:text-8xl font-serif mb-6 tracking-tight">Menu</h1>
          <p className="text-xs uppercase tracking-[0.4em] text-gray-400">Bestia Los Angeles</p>
        </div>

        {/* Categories */}
        {categories.map((cat) => (
          <div key={cat} className="mb-24">
            <div className="flex items-center mb-12">
              <h2 className="text-2xl font-serif tracking-widest text-red-700">{cat}</h2>
              <div className="flex-grow h-px bg-red-700/20 ml-6"></div>
            </div>
            
            <div className="space-y-10">
              {MENU_DATA.filter(item => item.category === cat).map(item => (
                <div key={item.id} className="group flex justify-between items-start gap-8">
                  <div className="flex-grow">
                    <h3 className="text-lg font-serif mb-1 tracking-wide group-hover:text-red-400 transition-colors">
                      {item.name}
                    </h3>
                    <p className="text-xs text-gray-500 italic font-light leading-relaxed uppercase tracking-tighter">
                      {item.description}
                    </p>
                  </div>
                  <div className="text-sm font-light text-gray-400 shrink-0">
                    {item.price}
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}

        {/* Wine Section */}
        <div className="mb-24 pt-16 border-t border-white/10">
          <div className="flex items-center mb-12">
            <h2 className="text-2xl font-serif tracking-widest text-red-700">WINE</h2>
            <div className="flex-grow h-px bg-red-700/20 ml-6"></div>
          </div>
          <p className="text-sm text-gray-400 leading-relaxed font-light mb-8 max-w-2xl italic">
            {WINE_INFO.text}
          </p>
          <p className="text-[10px] uppercase tracking-widest text-gray-600 mb-4">
            A comprehensive list of vintages by the glass and bottle is available upon request in the dining room.
          </p>
          <p className="text-[10px] uppercase tracking-widest text-gray-600">
            {WINE_INFO.corkage}
          </p>
        </div>

        {/* Footer info specific to menu */}
        <div className="text-center pt-16 border-t border-white/10 opacity-60">
          <p className="text-[10px] uppercase tracking-[0.3em] leading-loose text-gray-400">
            A 4% service charge is added to guest checks to support staff compensation and benefits. <br />
            Consuming raw or undercooked meats, poultry, seafood, or eggs may increase your risk of foodborne illness.
          </p>
        </div>
      </div>
      <style>{`
        @keyframes fade-in {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        .animate-fade-in {
          animation: fade-in 0.8s ease-out;
        }
      `}</style>
    </div>
  );
};

export default MenuPage;
