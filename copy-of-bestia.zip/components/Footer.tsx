
import React from 'react';
import { RESTAURANT_INFO } from '../constants';

const Footer: React.FC = () => {
  return (
    <footer className="bg-black py-20 border-t border-white/5">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid md:grid-cols-4 gap-12 mb-20">
          <div className="col-span-2">
            <h2 className="text-4xl font-serif mb-8 tracking-widest">BESTIA</h2>
            <p className="text-gray-500 text-sm max-w-sm mb-8 leading-relaxed font-light">
              Rustic Italian fare, house-made pastas & charcuterie in a bustling Arts District space.
            </p>
            <div className="flex space-x-6">
              <a href={RESTAURANT_INFO.social.instagram} className="text-gray-400 hover:text-white transition-colors">Instagram</a>
              <a href={RESTAURANT_INFO.social.facebook} className="text-gray-400 hover:text-white transition-colors">Facebook</a>
            </div>
          </div>
          
          <div>
            <h4 className="text-xs uppercase tracking-[0.3em] mb-8 text-gray-400">Newsletter</h4>
            <p className="text-xs text-gray-500 mb-6 font-light">Join our list for special event announcements and seasonal updates.</p>
            <div className="flex border-b border-white/20 pb-2">
              <input 
                type="email" 
                placeholder="Your email" 
                className="bg-transparent text-sm w-full focus:outline-none focus:border-red-700"
              />
              <button className="text-xs uppercase tracking-widest hover:text-red-500 transition-colors ml-4">Join</button>
            </div>
          </div>

          <div>
            <h4 className="text-xs uppercase tracking-[0.3em] mb-8 text-gray-400">Quick Links</h4>
            <ul className="space-y-4 text-xs uppercase tracking-widest text-gray-500">
              <li><a href="#" className="hover:text-white transition-colors">Careers</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Privacy Policy</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Accessibility</a></li>
            </ul>
          </div>
        </div>

        <div className="pt-12 border-t border-white/5 flex flex-col md:flex-row justify-between items-center text-[10px] uppercase tracking-[0.2em] text-gray-600 space-y-4 md:space-y-0 text-center">
          <p>&copy; {new Date().getFullYear()} Bestia Restaurant. All Rights Reserved.</p>
          <p>Photography by Ori Menashe & Genevieve Gergis.</p>
          <p className="max-w-xs md:max-w-none">
            A 4% service charge is added to all checks to support staff compensation.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
